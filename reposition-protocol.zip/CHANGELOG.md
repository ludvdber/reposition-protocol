## [0.0.1] - 2024-03-28

First push YIPPPPEEEEEE

### Added

- nickklmao-MenuLib
- BepInEx-BepInExPack
- RESET-MoreHeadPlus
- YMC_MHZ-MoreHead
- mattymatty-AsyncLoggers
- Zehs-REPOLib
- BULLETBOT-MoreUpgrades
- nickklmao-REPOConfig
- x753_REPO-CustomColors
- nickklmao-FreecamSpectate
- Magic_Wesley-Wesleys_Valuables
- zombieseatflesh7-ColoredNametags
- Magic_Wesley-Wesleys_Enemies
- Rangerbb275-REPOing_Valuables
- ColtG5-BoomboxCart --> All my love to Maxima
- JacuJ-SillyWeaponSounds
- loaforc-loaforcsSoundAPI
- SteamBlizzard-StalkerGoku
- Caigan-Tokucade_Valuables
- linkoid-StableFlashlight

